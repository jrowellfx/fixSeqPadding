# fixSeqPadding

Cmd-line util to repair badly-padded frames in image-sequences.

